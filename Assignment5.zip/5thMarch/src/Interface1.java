
public interface Interface1 {
	default void defaultMethod()
	{
		System.out.println("This is the default method indeed.");
	}
	void notDefaultMethod();
}
