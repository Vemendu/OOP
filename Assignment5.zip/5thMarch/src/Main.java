import java.lang.reflect.*;
public class Main{
	

	public static void main(String[] args) {
		int data=0;
		String string = "";
		Interface1 interface1;
		try {
			Class Class0 = Class.forName("Class1");
			Class1 class1 = (Class1) Class0.newInstance();
			class1.someMethod1();
			class1.someMethod2();
			Field field = class1.getClass().getDeclaredField("firstField");
			field.setAccessible(true);
			data = (Integer) field.get(class1);
			Field field1 = class1.getClass().getDeclaredField("secondField");
			field1.setAccessible(true);
			string = (String) field1.get(class1);
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		catch (NoSuchFieldException e) 
			{
		       e.printStackTrace();
			}
		System.out.println(data);
		System.out.println(string);
	}

}
