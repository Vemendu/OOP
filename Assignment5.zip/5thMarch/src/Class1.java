
public class Class1 {
	private int firstField;
	private String secondField;
	public Class1()
	{
		this.firstField=1;
		this.secondField="secondFieldText";
	}
	public void someMethod1()
	{
		firstField=5;
	}
	public void someMethod2()
	{
		secondField="Methoded.";
	}
}
